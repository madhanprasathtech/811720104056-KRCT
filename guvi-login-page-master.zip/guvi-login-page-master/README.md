# guvi login page (Internship Challenge)

Hosted Web link https://kuttyma.000webhostapp.com

<h3>Technologies used</h3>
<ul>
  <li>PHP AJAX Requests</li>
  <li>jquery</li>
  <li>Bootstrap</li>
  <li>Mysql</li>
</ul>
  
  <h3>Features</h3>
<ul>
  <li>Email Verification for User Registration </li>
  <li>Reset password Feature</li>
  <li>Encrypted Data</li>
  <li>Responsive Layout</li>
  <li>Remember Login Session</li>
</ul>
  
  <h3>PAGE 1 : LOGIN</h3>
  <img src="https://4.bp.blogspot.com/-ot1fJZfprbg/XLtQPYCZw9I/AAAAAAAAKAs/u3Tx-X2lNW855ty3tORTuL8miFYcyF5xQCLcBGAs/s1600/login.png"></img>
   <h3>PAGE 2 : REGISTER</h3>
   <img src="https://4.bp.blogspot.com/-KjeEvKVHXjw/XLtQSPtgxQI/AAAAAAAAKA8/aPHXFQr8dyIy4buIB6YlDLBQUvP_PRlTgCLcBGAs/s1600/reg.png">
  </img>
   <h3>PAGE 3 : RECOVER</h3>
  <img src="https://1.bp.blogspot.com/-qE4NwUUbjKA/XLtQRljg8sI/AAAAAAAAKA4/84BnehAA9hUxOF6LYcnry-_K-gXzAMlOgCLcBGAs/s1600/recover.png"></img>
   <h3>PAGE 4 : PROFILE</h3>
   <img src="https://1.bp.blogspot.com/-6HFeiHGUCpc/XLtQQSlv61I/AAAAAAAAKA0/64yPXy3mUjQj87lg8LkMl5NoNmdfFxtMQCLcBGAs/s1600/profile.png">
  </img>
   <h3>PAGE 5 : RESET</h3>
  <img src="https://4.bp.blogspot.com/-A3XC0fyU97E/XLtQSfKJ_YI/AAAAAAAAKBA/BzH89J0OneYEI7oB9L8uSbTz5ZabmXGWgCLcBGAs/s1600/reset.png"></img>
  <h3>PAGE 6 : JSON</h3>
  <img src="https://4.bp.blogspot.com/-TnFt0Hati6Q/XLtQPZfMejI/AAAAAAAAKAw/1WdjdybXnB8kcp_1V2l1D2o9CgX5FAVowCLcBGAs/s1600/json.png"></img>
   <h3>PAGE 6 : Email verification</h3>
  <img src="https://4.bp.blogspot.com/-LFLamMRD0Xw/XLtWfcFWQCI/AAAAAAAAKBc/4fUy-Y7n0RMf0wv4RAwO7nUElvGeltIBQCLcBGAs/s1600/mail.png"></img>
  
