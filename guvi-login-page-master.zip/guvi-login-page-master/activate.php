<?php include("includes/header.php") ?>
<?php include("includes/nav.php") ?>



<div class="container">




	<div class="jumbotron">
		<h1 class="text-center">Activate</h1>
		<?php activate_user(); ?>
	</div>



</div> <!--Container-->




<?php include("includes/footer.php") ?>
