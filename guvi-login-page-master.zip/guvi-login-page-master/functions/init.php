<?php ob_start();
session_start();
include("db.php");
include("functions.php");
include("ajax.php");

if($con){
//  echo "it works";
}

 ?>
